# Parkeez – UF-prototyp

En statisk webbprototyp för att jämföra exempelparkeringar i Göteborg.

Viktigt: platser och priser i prototypen är demodata och visar inte verklig tillgänglighet. Verifiera parkeringsuppgifter och kontrollera användningsvillkor innan offentlig lansering.

Publicering: ladda upp `index.html` till ett GitHub-repository och välj Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.
